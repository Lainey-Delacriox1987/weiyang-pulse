export type TeamDraft = { name: string; projectName: string; idea: string };

export const TEAM_LIMITS = { nameMin: 2, nameMax: 28, projectMin: 2, projectMax: 40, ideaMin: 4, ideaMax: 90 } as const;

export function normalizeTeamKey(value: string) {
  return value.normalize("NFKC").trim().replace(/\s+/gu, " ").replace(/[A-Z]/g, letter => letter.toLowerCase());
}

export function projectTitle(team: { name: string; projectName?: string }) {
  return team.projectName?.trim() || team.name;
}

export function validateTeamDraft(input: Record<string, unknown>): TeamDraft {
  const field = (key: string, label: string, min: number, max: number) => {
    const raw = input[key];
    if (typeof raw !== "string") throw new Error(`请填写${label}。`);
    const value = (key === "idea" ? raw : raw.normalize("NFKC")).trim().replace(/\s+/gu, " ");
    if (!/[^\s\u200B-\u200D\uFEFF]/u.test(value) || value.length < min) throw new Error(`${label}至少需要 ${min} 个字符。`);
    if (value.length > max) throw new Error(`${label}不能超过 ${max} 个字符。`);
    if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/u.test(value)) throw new Error(`${label}包含无法显示的字符，请修改后重试。`);
    return value;
  };
  return {
    name: field("name", "队伍名称", TEAM_LIMITS.nameMin, TEAM_LIMITS.nameMax),
    projectName: field("projectName", "作品名称", TEAM_LIMITS.projectMin, TEAM_LIMITS.projectMax),
    idea: field("idea", "作品简介", TEAM_LIMITS.ideaMin, TEAM_LIMITS.ideaMax),
  };
}

type StoredTeam = { id: string; name: string; project_name: string; idea: string };

// The ID is stable for a retry of this device's request, without publishing the
// device identifier or storing private ownership fields in the public team row.
export async function teamRequestId(actor: string, requestId: unknown) {
  if (typeof requestId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(requestId)) {
    throw new Error("请刷新页面后重新登记队伍和作品。");
  }
  const bytes = new TextEncoder().encode(`${actor}:${requestId}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

export async function registerTeam(db: Pick<D1Database, "prepare">, input: Record<string, unknown>, actor: string, now: number) {
  const draft = validateTeamDraft(input);
  const id = await teamRequestId(actor, input.requestId);
  const nameKey = normalizeTeamKey(draft.name);
  const projectKey = normalizeTeamKey(draft.projectName);
  const replay = async () => {
    const row = await db.prepare("SELECT id, name, project_name, idea FROM teams WHERE id = ?").bind(id).first<StoredTeam>();
    if (!row) return null;
    if (row.name !== draft.name || row.project_name !== draft.projectName || row.idea !== draft.idea) throw new Error("这次登记的内容已变化，请重新提交。");
    return { ok: true, teamId: row.id };
  };
  const existing = await replay();
  if (existing) return existing;

  const checkNames = async () => {
    const result = await db.prepare("SELECT id, name, project_name, idea FROM teams").all<StoredTeam>();
    // Normalize legacy labels for comparison without rewriting historical rows.
    if (result.results.some(row => normalizeTeamKey(row.name) === nameKey)) throw new Error("这个队伍名称已被使用，请换一个。");
    if (result.results.some(row => normalizeTeamKey(row.project_name || row.name) === projectKey)) throw new Error("这个作品名称已登记，请换一个。");
  };
  await checkNames();
  const code = `${draft.name.replace(/\s/gu, "").slice(0, 6).toUpperCase()}-${id}`;
  const saved = await db.prepare("INSERT INTO teams (id, code, name, project_name, idea, created_at) SELECT ?, ?, ?, ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM teams WHERE name = ? COLLATE NOCASE OR (CASE WHEN project_name = '' THEN name ELSE project_name END) = ? COLLATE NOCASE) ON CONFLICT DO NOTHING")
    .bind(id, code, draft.name, draft.projectName, draft.idea, now, draft.name, draft.projectName).run();
  if (Number(saved.meta.changes) === 1) return { ok: true, teamId: id };
  const duplicateRequest = await replay();
  if (duplicateRequest) return duplicateRequest;
  await checkNames();
  throw new Error("登记暂时未完成，请重试；你的输入会保留。");
}
