import type { Team } from "./use-market";

// Ranking uses the server's full vote aggregate, never its limited activity feed.
export function buildVoteRanking(teams: Team[], counts: Record<string, number>, totalVotes?: number) {
  const ranked = teams.map(team => {
    const value = counts[team.id] ?? 0;
    return { ...team, votes: Number.isSafeInteger(value) && value > 0 ? value : 0 };
  }).sort((a, b) => b.votes - a.votes || a.createdAt - b.createdAt || a.id.localeCompare(b.id));
  const displayedTotal = ranked.reduce((sum, team) => sum + team.votes, 0);
  const total = totalVotes !== undefined && Number.isSafeInteger(totalVotes) && totalVotes >= 0 ? totalVotes : displayedTotal;
  const consistent = total >= displayedTotal;
  const voteFrequency = new Map<number, number>();
  for (const team of ranked) voteFrequency.set(team.votes, (voteFrequency.get(team.votes) ?? 0) + 1);
  let previousVotes = -1;
  let place = 0;
  const rows = ranked.map((team, index) => {
    if (team.votes !== previousVotes) place = index + 1;
    previousVotes = team.votes;
    return {
      ...team,
      place: team.votes > 0 ? place : null,
      tied: team.votes > 0 && (voteFrequency.get(team.votes) ?? 0) > 1,
      share: consistent && total > 0 ? team.votes / total * 100 : null,
    };
  });
  return { rows, total, displayedTotal, consistent };
}

export function formatVoteShare(share: number | null) {
  if (share === null) return "—";
  if (share === 0) return "0%";
  if (share < 0.1) return "<0.1%";
  return `${share.toFixed(1)}%`;
}
