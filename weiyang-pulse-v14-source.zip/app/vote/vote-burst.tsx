"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import "./vote-burst.css";

export type VoteBurstData = { id: string; team: string; demo: boolean };

export default function VoteBurst({ burst }: { burst: VoteBurstData | null }) {
  const [visible, setVisible] = useState(false);
  const [reduced,setReduced] = useState(false);
  const [flowerReady, setFlowerReady] = useState(false);
  const [viewport, setViewport] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const flowerRef = useRef<HTMLImageElement | null>(null);
  const burstId = burst?.id;

  // iOS browser chrome, safe-area and keyboard can change the visual viewport
  // without changing the layout viewport. Keep the decoration inside what is visible.
  useEffect(() => {
    if (!burstId) return;
    const visual = window.visualViewport;
    let frame = 0;
    const update = () => setViewport({ top: visual?.offsetTop || 0, left: visual?.offsetLeft || 0, width: visual?.width || window.innerWidth, height: visual?.height || window.innerHeight });
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(update); };
    schedule();
    visual?.addEventListener("resize", schedule);
    visual?.addEventListener("scroll", schedule);
    window.addEventListener("resize", schedule);
    return () => { cancelAnimationFrame(frame); visual?.removeEventListener("resize", schedule); visual?.removeEventListener("scroll", schedule); window.removeEventListener("resize", schedule); };
  }, [burstId]);

  useEffect(() => {
    if (!visible) return;
    const close = () => { setVisible(false); };
    const key = (event: KeyboardEvent) => { if (event.key === "Escape") close(); };
    const hidden = () => { if (document.hidden) close(); };
    document.addEventListener("keydown", key);
    document.addEventListener("visibilitychange", hidden);
    return () => { document.removeEventListener("keydown", key); document.removeEventListener("visibilitychange", hidden); };
  }, [visible]);

  /* eslint-disable react-hooks/set-state-in-effect -- Synchronize a transient media overlay with a new confirmed event; timers and media are cleaned up. */
  useEffect(() => {
    if (!burstId) return;
    setVisible(false);
    setFlowerReady(false);
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setReduced(true);setVisible(true);
      const timer=window.setTimeout(()=>setVisible(false),3450);
      return()=>window.clearTimeout(timer);
    }
    setReduced(false);
    {
      const artwork = flowerRef.current;
      let cancelled = false;
      let started = false;
      let visibleTimer = 0;
      const reveal = (loaded: boolean) => {
        if (cancelled || started) return;
        started = true;
        window.clearTimeout(loadTimer);
        setFlowerReady(loaded);
        setVisible(true);
        visibleTimer = window.setTimeout(() => setVisible(false), 3450);
      };
      // A slow/failed image gets the text receipt rather than a partially loaded flower.
      const loadTimer = window.setTimeout(() => reveal(false), 5000);
      const loaded = () => reveal(true);
      const failed = () => reveal(false);
      if (!artwork) failed();
      else if (typeof artwork.decode === "function") void artwork.decode().then(loaded, failed);
      else if (artwork.complete && artwork.naturalWidth > 0) loaded();
      else { artwork.addEventListener("load", loaded, { once: true }); artwork.addEventListener("error", failed, { once: true }); }
      return () => { cancelled = true; window.clearTimeout(loadTimer); window.clearTimeout(visibleTimer); artwork?.removeEventListener("load", loaded); artwork?.removeEventListener("error", failed); };
    }
  }, [burstId]);
  /* eslint-enable react-hooks/set-state-in-effect */

  if (!burst) return null;
  return <div className={`vote-celebration ${visible ? "is-visible" : ""}`} style={viewport ? { top: viewport.top, left: viewport.left, width: viewport.width, height: viewport.height } : undefined}>
    <div className={`vote-burst ${visible ? "is-visible" : ""}`} style={reduced?{display:"none"}:undefined} key={`${burst.id}-effect`} aria-hidden="true">
      {reduced ? null : <>
        <img ref={flowerRef} className="vote-burst-flower" src="/effects/flower-cutout.png" alt="" hidden={!flowerReady} />
        <div className="vote-flower-petals">{Array.from({ length: 72 }, (_, index) => <i key={index} style={{
          "--petal-x": `${(index % 12) * 8.4 + ((index * 7) % 6)}%`,
          "--petal-y": `${Math.floor(index / 12) * 18 - 18 + ((index * 11) % 13)}%`,
          "--petal-size": `${10 + ((index * 7) % 12)}px`,
          "--petal-drift": `${((index * 17) % 35) - 17}vw`,
          "--petal-turn": `${(index * 137) % 360}deg`,
          "--petal-delay": `${(index % 8) * 0.035}s`,
        } as CSSProperties}/>)}</div>
      </>}
    </div>
    <div className={`vote-burst-copy-layer ${visible ? "is-visible" : ""}`} key={`${burst.id}-copy`} aria-live="polite">
      <small>{burst.demo ? "PREVIEW EFFECT" : "NEW VOTE"}</small>
      <strong>{burst.team}</strong>
      <span>{burst.demo ? "演示支持已送达" : "服务器已确认这一票"}</span>
      <small>AI 生成庆祝素材 · 仅视觉反馈</small>
      <button className="celebration-dismiss" onClick={()=>setVisible(false)}>跳过特效</button>
    </div>
  </div>;
}
