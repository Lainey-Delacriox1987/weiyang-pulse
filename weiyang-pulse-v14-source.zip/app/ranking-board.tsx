"use client";

import { useLayoutEffect, useRef, useState, type CSSProperties } from "react";
import type { Team } from "@/lib/use-market";
import { buildVoteRanking, formatVoteShare } from "@/lib/vote-ranking";
import { sampleIds } from "./event-ui";
import { projectTitle } from "@/lib/team-registration";
import "./vote-results.css";

const tabs = ["人气", "声浪", "评委", "总榜"] as const;

type RankingBoardProps = {
  teams: Team[];
  counts: Record<string, number>;
  totalVotes?: number;
  demo?: boolean;
  loading?: boolean;
  error?: string;
};

export default function RankingBoard({ teams, counts, totalVotes, demo = false, loading = false, error = "" }: RankingBoardProps) {
  const [tab, setTab] = useState(0);
  const rows = useRef<HTMLOListElement | null>(null);
  const previous = useRef(new Map<string, number>());
  const results = buildVoteRanking(teams, counts, demo ? undefined : totalVotes);
  const key = results.rows.map(team => `${team.id}:${team.votes}`).join("|");

  useLayoutEffect(() => {
    const next = new Map<string, number>();
    rows.current?.querySelectorAll<HTMLElement>("[data-team]").forEach(node => {
      const id = node.dataset.team!;
      const top = node.getBoundingClientRect().top + window.scrollY;
      next.set(id, top);
      const old = previous.current.get(id);
      if (old !== undefined && old !== top && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
        node.animate([{ transform: `translateY(${old - top}px)` }, { transform: "translateY(0)" }], { duration: 320, easing: "ease-out" });
      }
    });
    previous.current = next;
  }, [key, tab]);

  return <div className="ranking-board" data-results-mode={demo ? "demo" : "live"}>
    <small>{demo ? "LOCAL DEMO / 本地演示" : "LIVE / 真实投票"}</small>
    <h2>每一票，都看得见。</h2>
    <div className="ranking-tabs" role="tablist" aria-label="榜单类型">
      {tabs.map((label, index) => <button key={label} id={`rank-tab-${label}`} role="tab" aria-selected={tab === index} aria-controls={`rank-panel-${label}`} tabIndex={tab === index ? 0 : -1} onClick={() => setTab(index)} onKeyDown={event => {
        if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
          event.preventDefault();
          const next = (index + (event.key === "ArrowRight" ? 1 : 3)) % 4;
          setTab(next);
          event.currentTarget.parentElement?.querySelectorAll<HTMLButtonElement>("button")[next]?.focus();
        }
      }}>{label}</button>)}
    </div>
    <section role="tabpanel" id={`rank-panel-${tabs[tab]}`} aria-labelledby={`rank-tab-${tabs[tab]}`} tabIndex={0}>
      {tab === 0 ? <>
        <p>{demo ? "仅当前浏览器的演示票数，不计入正式结果。" : "服务器确认的真实票数，每 3 秒更新。"}横条表示票数占比，同票并列。</p>
        {loading && !demo ? <div className="vote-results-empty" role="status"><strong>{error ? "暂时无法读取票数" : "正在读取真实票数…"}</strong><p>{error ? "连接恢复后自动更新，当前不显示未经确认的结果。" : "等待服务器确认后展示榜单。"}</p></div> : <>
          {error && !demo && <p role="status">连接恢复中，当前保留上一次确认的结果。</p>}
          <div className="vote-chart-summary-row" role="status"><strong><span className="vote-number-change" key={results.total}>{results.total.toLocaleString("zh-CN")}</span><small>{demo ? "票 · 本机演示" : "票 · 服务器已确认"}</small></strong><span>{teams.length} 件作品</span></div>
          {results.total === 0 && <div className="vote-results-empty"><strong>{demo ? "还没有演示票" : "第一份支持，还在路上。"}</strong><p>{demo ? "在本机演示中选择作品，体验票数变化。" : "收到真实投票后，横条与排名会自动更新。"}0 票作品暂不分配名次。</p></div>}
          {!results.consistent && <p role="status">票数正在同步，占比暂不展示。</p>}
          {results.total > results.displayedTotal && <p>另有 {results.total - results.displayedTotal} 票暂无对应作品；占比仍按全部已确认票数计算。</p>}
          <ol className="vote-ranking-chart" ref={rows} aria-label={demo ? "本机演示投票结果，按票数排序" : "真实投票结果，按票数排序"}>
            {results.rows.map(team => <li className="vote-result-row" data-team={team.id} data-place={team.place ?? "none"} key={team.id}>
              <div className="vote-result-heading">
                <span className="vote-result-place" aria-label={team.place ? `${team.tied ? "并列" : ""}第 ${team.place} 名` : "暂无名次"}>{team.place ? String(team.place).padStart(2, "0") : "—"}</span>
                <strong className="vote-result-name">{projectTitle(team)}{(team.projectName || sampleIds.has(team.id) || team.tied) && <small>{[team.projectName ? `队伍：${team.name}` : "", sampleIds.has(team.id) ? "示例作品" : "", team.tied ? `并列第 ${team.place} 名` : ""].filter(Boolean).join(" · ")}</small>}</strong>
                <span className="vote-result-value"><span className="vote-number-change" key={team.votes}>{team.votes.toLocaleString("zh-CN")}</span><small>票</small></span>
              </div>
              <div className="vote-result-track" aria-hidden="true"><span className="vote-result-fill" style={{ "--vote-share": `${team.share ?? 0}%` } as CSSProperties} /></div>
              <span className="vote-result-share">{team.share === null ? "占比 —" : `${formatVoteShare(team.share)} · ${demo ? "演示票数占比" : "真实票数占比"}`}</span>
            </li>)}
          </ol>
        </>}
      </> : tab === 1 ? <div className="rank-pending"><strong>把现场的回应，变成声浪。</strong><p>30 秒本地互动，可选麦克风。数值是娱乐测量，未经分贝校准；不用于跨设备公平评审，不计入官方总分。声音不上传、不保存。</p><a className="event-button" href="/play">开启本地声浪体验 ↗</a></div> : tab === 2 ? <div className="rank-pending"><strong>评委分数 · 待录入</strong><p>尚无经组织者确认的评分数据。正式评分规则与受保护的录入流程配置后，才能展示评委榜。</p></div> : <div className="rank-pending"><strong>总榜 · 规则待配置</strong><p>人气、声浪与评委分数的权重尚未确认。目前不生成官方总分，也不把娱乐声浪与真实票数直接相加。</p></div>}
    </section>
    <a href="/screen" className="event-link">打开现场大屏 ↗</a>
  </div>;
}
