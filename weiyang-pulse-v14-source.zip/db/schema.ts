import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const teams = sqliteTable("teams", {
  id: text("id").primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  projectName: text("project_name").notNull().default(""),
  idea: text("idea").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [uniqueIndex("idx_teams_code").on(table.code)]);

export const events = sqliteTable("events", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  teamId: text("team_id").references(() => teams.id),
  actor: text("actor").notNull(),
  label: text("label").notNull().default(""),
  note: text("note").notNull().default(""),
  status: text("status").notNull().default("open"),
  demo: integer("demo").notNull().default(0),
  createdAt: integer("created_at").notNull(),
}, (table) => [index("idx_events_created_at").on(table.createdAt), index("idx_events_actor_kind").on(table.actor, table.kind)]);
