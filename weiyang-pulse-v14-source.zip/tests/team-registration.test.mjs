import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { registerTeam, validateTeamDraft, normalizeTeamKey, projectTitle } from '../lib/team-registration.ts';
import { buildVoteRanking } from '../lib/vote-ranking.ts';

const oldMigration = readFileSync(new URL('../drizzle/0000_massive_hellfire_club.sql', import.meta.url), 'utf8');
const newMigration = readFileSync(new URL('../drizzle/0001_hot_harpoon.sql', import.meta.url), 'utf8');
const actor = 'test-device-12345';
const draft = { name: '本地测试队伍', projectName: '本地测试作品', idea: '仅用于隔离数据库测试，不提交到生产。' };
const input = (override = {}) => ({ ...draft, requestId: crypto.randomUUID(), ...override });

function fixture(t, legacy = true) {
  const sql = new DatabaseSync(':memory:');
  t.after(() => sql.close());
  sql.exec('PRAGMA foreign_keys = ON');
  sql.exec(oldMigration);
  if (legacy) {
    sql.prepare('INSERT INTO teams (id, code, name, idea, created_at) VALUES (?, ?, ?, ?, ?)').run('old', 'OLD', '历史队伍', '历史简介保持不变', 1);
    sql.prepare("INSERT INTO events (id, kind, team_id, actor, status, demo, created_at) VALUES ('old-vote', 'vote', 'old', 'original-device', 'open', 0, 2)").run();
  }
  sql.exec(newMigration);
  const options = { failAfterCommit: false };
  const db = {
    prepare(query) {
      let params = [];
      const wrapper = {
        bind(...values) { params = values; return wrapper; },
        async first() { await Promise.resolve(); return sql.prepare(query).get(...params) ?? null; },
        async all() { await Promise.resolve(); return { results: sql.prepare(query).all(...params), success: true }; },
        async run() {
          await Promise.resolve();
          const result = sql.prepare(query).run(...params);
          if (options.failAfterCommit && query.startsWith('INSERT INTO teams')) { options.failAfterCommit = false; throw new Error('simulated lost response after committed write'); }
          return { success: true, meta: { changes: Number(result.changes) } };
        },
      };
      return wrapper;
    },
  };
  return { sql, db, options };
}

function snapshot(sql) {
  const teams = sql.prepare('SELECT id, code, name, project_name AS projectName, idea, created_at AS createdAt FROM teams ORDER BY created_at').all();
  const rows = sql.prepare("SELECT team_id AS teamId, count(*) AS count FROM events WHERE kind = 'vote' AND status = 'open' AND demo = 0 GROUP BY team_id").all();
  return { teams, voteCounts: Object.fromEntries(rows.filter(row => row.teamId).map(row => [row.teamId, row.count])), totalVotes: rows.reduce((sum, row) => sum + row.count, 0) };
}

test('rejects blank, wrong-type, invisible, short and overlong fields without truncating', () => {
  assert.throws(() => validateTeamDraft({ ...draft, name: '   ' }), /队伍名称/);
  assert.throws(() => validateTeamDraft({ ...draft, name: '\u200b\u200b' }), /队伍名称/);
  assert.throws(() => validateTeamDraft({ ...draft, projectName: {} }), /作品名称/);
  assert.throws(() => validateTeamDraft({ ...draft, idea: '短' }), /作品简介/);
  assert.throws(() => validateTeamDraft({ ...draft, name: 'a'.repeat(29) }), /不能超过/);
  assert.throws(() => validateTeamDraft({ ...draft, projectName: 'p'.repeat(41) }), /不能超过/);
  assert.throws(() => validateTeamDraft({ ...draft, idea: 'x'.repeat(91) }), /不能超过/);
  assert.equal(validateTeamDraft({ name: 'a'.repeat(28), projectName: 'p'.repeat(40), idea: 'x'.repeat(90) }).idea.length, 90);
});

test('normalization is explicit: Unicode compatibility, whitespace and ASCII case', () => {
  assert.equal(normalizeTeamKey('  Ａlpha   Team '), 'alpha team');
  assert.equal(validateTeamDraft({ ...draft, name: '  Alpha   Team ' }).name, 'Alpha Team');
});

test('additive migration preserves historical rows/votes and remains writable by v13', t => {
  const { sql } = fixture(t);
  const before = snapshot(sql);
  assert.equal(before.teams[0].projectName, '');
  assert.equal(projectTitle(before.teams[0]), '历史队伍');
  assert.equal(before.totalVotes, 1);
  sql.prepare("INSERT INTO teams (id, code, name, idea, created_at) VALUES ('old-client', 'OC', '旧版新增', '兼容旧版写入', 3)").run();
  assert.equal(sql.prepare("SELECT project_name FROM teams WHERE id = 'old-client'").get().project_name, '');
  assert.equal(snapshot(sql).totalVotes, 1);
});

test('creates durable team/project visible in refreshed shared state and zero-vote ranking', async t => {
  const { sql, db } = fixture(t);
  const result = await registerTeam(db, input(), actor, 10);
  const state = snapshot(sql);
  const created = state.teams.find(team => team.id === result.teamId);
  assert.ok(created);
  assert.equal(created.name, draft.name);
  assert.equal(created.projectName, draft.projectName);
  assert.equal(created.idea, draft.idea);
  assert.equal(projectTitle(created), draft.projectName);
  assert.equal(state.teams.length, 2);
  assert.equal(state.totalVotes, 1);
  const ranking = buildVoteRanking(state.teams, state.voteCounts, state.totalVotes);
  assert.equal(ranking.rows.find(team => team.id === result.teamId).votes, 0);
  assert.equal(ranking.rows.find(team => team.id === result.teamId).place, null);
});

test('eight concurrent copies of one request yield exactly one durable row and one ID', async t => {
  const { sql, db } = fixture(t, false);
  const request = input();
  const results = await Promise.all(Array.from({ length: 8 }, () => registerTeam(db, request, actor, 10)));
  assert.equal(new Set(results.map(result => result.teamId)).size, 1);
  assert.equal(sql.prepare('SELECT count(*) AS n FROM teams').get().n, 1);
});

test('lost response can be retried safely; changed payload cannot reuse a request ID', async t => {
  const { sql, db, options } = fixture(t, false);
  const request = input();
  options.failAfterCommit = true;
  await assert.rejects(registerTeam(db, request, actor, 10), /lost response/);
  const replay = await registerTeam(db, request, actor, 20);
  assert.equal(sql.prepare('SELECT count(*) AS n FROM teams').get().n, 1);
  assert.equal(sql.prepare('SELECT id FROM teams').get().id, replay.teamId);
  await assert.rejects(registerTeam(db, { ...request, idea: '同一次请求不能改成另一份内容' }, actor, 30), /内容已变化/);
});

test('concurrent normalized duplicate team names are atomically rejected', async t => {
  const { sql, db } = fixture(t, false);
  const results = await Promise.allSettled(Array.from({ length: 8 }, (_, i) => registerTeam(db, input({ name: i % 2 ? 'alpha team' : '  Ａlpha   Team ', projectName: `不同作品${i}` }), `device-${i}-0000`, 10)));
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(results.filter(result => result.status === 'rejected' && /队伍名称已被使用/.test(result.reason.message)).length, 7);
  assert.equal(sql.prepare('SELECT count(*) AS n FROM teams').get().n, 1);
});

test('concurrent duplicate project titles are rejected independently of team name', async t => {
  const { sql, db } = fixture(t, false);
  const results = await Promise.allSettled(Array.from({ length: 5 }, (_, i) => registerTeam(db, input({ name: `不同队伍${i}`, projectName: i % 2 ? 'same project' : 'Same Project' }), `device-${i}-0000`, 10)));
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(results.filter(result => result.status === 'rejected' && /作品名称已登记/.test(result.reason.message)).length, 4);
  assert.equal(sql.prepare('SELECT count(*) AS n FROM teams').get().n, 1);
});

test('historical displayed names also prevent duplicate team or project registration', async t => {
  const { db } = fixture(t);
  await assert.rejects(registerTeam(db, input({ name: '  历史队伍 ' }), actor, 10), /队伍名称已被使用/);
  await assert.rejects(registerTeam(db, input({ projectName: '历史队伍' }), actor, 10), /作品名称已登记/);
});

test('HTML-like content is stored as text and safely escaped for display', async t => {
  const { db, sql } = fixture(t, false);
  const request = input({ name: '<团队>', projectName: '<img src=x onerror=alert(1)>', idea: '<script>alert("x")</script>' });
  const result = await registerTeam(db, request, actor, 10);
  const team = snapshot(sql).teams.find(row => row.id === result.teamId);
  const rendered = renderToStaticMarkup(createElement('article', null, createElement('h3', null, projectTitle(team)), createElement('small', null, team.name), createElement('p', null, team.idea)));
  assert.match(rendered, /&lt;img/);
  assert.match(rendered, /&lt;script/);
  assert.doesNotMatch(rendered, /<img|<script/);
});

test('missing request token cannot create an unconfirmed or non-idempotent record', async t => {
  const { db, sql } = fixture(t, false);
  await assert.rejects(registerTeam(db, { ...draft }, actor, 10), /刷新页面/);
  assert.equal(sql.prepare('SELECT count(*) AS n FROM teams').get().n, 0);
});
