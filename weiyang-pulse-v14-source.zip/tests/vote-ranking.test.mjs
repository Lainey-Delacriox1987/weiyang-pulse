import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { buildVoteRanking, formatVoteShare } from '../lib/vote-ranking.ts';

const teams = ['a', 'b', 'c', 'd'].map((id, index) => ({ id, name: `测试作品 ${id}`, code: id, idea: '仅用于离线测试', createdAt: index }));

test('sorts complete aggregate counts, even beyond the 150-event activity window', () => {
  const result = buildVoteRanking(teams, { a: 25, b: 300, c: 75, d: 0 }, 400);
  assert.deepEqual(result.rows.map(row => row.id), ['b', 'c', 'a', 'd']);
  assert.equal(result.total, 400);
  assert.deepEqual(result.rows.map(row => row.share), [75, 18.75, 6.25, 0]);
  assert.deepEqual(result.rows.map(row => row.place), [1, 2, 3, null]);
});

test('ties share competition rank, with stable order and no arbitrary top-three truncation', () => {
  const result = buildVoteRanking(teams, { a: 5, b: 5, c: 2, d: 0 });
  assert.deepEqual(result.rows.map(row => row.place), [1, 1, 3, null]);
  assert.deepEqual(result.rows.map(row => row.tied), [true, true, false, false]);
  assert.deepEqual(buildVoteRanking([...teams].reverse(), { a: 1, b: 1, c: 1, d: 1 }).rows.map(row => row.id), ['a', 'b', 'c', 'd']);
  assert.equal(buildVoteRanking(teams, { a: 1, b: 1, c: 1, d: 1 }).rows.filter(row => row.place <= 3).length, 4);
});

test('zero votes invent neither ranking nor a percentage denominator', () => {
  const result = buildVoteRanking(teams, {}, 0);
  assert.equal(result.total, 0);
  assert.ok(result.rows.every(row => row.votes === 0 && row.place === null && row.share === null));
  assert.equal(formatVoteShare(null), '—');
});

test('first real vote fills exactly 100 percent; zero-vote competitors stay empty', () => {
  const result = buildVoteRanking(teams, { c: 1 }, 1);
  assert.equal(result.rows[0].id, 'c');
  assert.equal(result.rows[0].share, 100);
  assert.ok(result.rows.slice(1).every(row => row.share === 0 && row.place === null));
});

test('server total remains denominator if some confirmed votes have no visible team', () => {
  const result = buildVoteRanking(teams, { a: 3, missing: 1 }, 4);
  assert.equal(result.displayedTotal, 3);
  assert.equal(result.total, 4);
  assert.equal(result.rows[0].share, 75);
  assert.equal(result.total - result.displayedTotal, 1);
});

test('inconsistent total suppresses misleading percentages rather than inventing votes', () => {
  const result = buildVoteRanking(teams, { a: 10 }, 5);
  assert.equal(result.consistent, false);
  assert.equal(result.rows[0].votes, 10);
  assert.equal(result.rows[0].share, null);
});

test('demo totals are independent from formal counts and do not mutate either input', () => {
  const live = { a: 2, b: 6 };
  const demo = { c: 3 };
  assert.equal(buildVoteRanking(teams, demo).total, 3);
  assert.equal(buildVoteRanking(teams, live, 8).total, 8);
  assert.deepEqual(live, { a: 2, b: 6 });
  assert.deepEqual(demo, { c: 3 });
});

test('display formatting handles thirds and tiny positive shares', () => {
  assert.equal(formatVoteShare(100 / 3), '33.3%');
  assert.equal(formatVoteShare(0.001), '<0.1%');
  assert.equal(formatVoteShare(0), '0%');
});

test('all celebrations use the complete flower; historical video assets remain untouched', () => {
  const source = readFileSync(new URL('../app/vote/vote-burst.tsx', import.meta.url), 'utf8');
  assert.match(source, /flower-cutout\.png/);
  assert.match(source, /artwork\.decode\(\)/);
  assert.match(source, /visualViewport/);
  assert.doesNotMatch(source, /pickVideo|prepareRenderer|<video|<canvas|webgl|rocket\.mp4/);
  assert.ok(existsSync(new URL('../public/videos/rocket.mp4', import.meta.url)));
  assert.ok(existsSync(new URL('../public/effects/flower-cutout.png', import.meta.url)));
});
