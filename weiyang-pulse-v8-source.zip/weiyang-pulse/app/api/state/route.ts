import { marketSnapshot } from "@/lib/market";

export const dynamic = "force-dynamic";
export async function GET() {
  try { return Response.json(await marketSnapshot(), { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { console.error(error); return Response.json({ error: "现场数据暂时不可用，请稍后重试。" }, { status: 500 }); }
}
