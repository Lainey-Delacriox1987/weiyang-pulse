"use client";
import { useEffect,useState } from "react";
import { ArrowUpRight, Check, Vote } from "lucide-react";
import { sendAction, useMarket } from "@/lib/use-market";
import { EventHeader,SampleNotice,sampleIds } from "../event-ui";
import RankingBoard from "../ranking-board";
import VoteBurst, { type VoteBurstData } from "./vote-burst";
import "./vote.css";
import "../event-design.css";
const demoTeams=[{id:"demo-1",code:"WY",name:"未央创造队",idea:"让现场的每个点子被看见",createdAt:0},{id:"demo-2",code:"404",name:"灵感实验室",idea:"用小小的作品回应真实的问题",createdAt:0},{id:"demo-3",code:"GO",name:"今晚就上线",idea:"把第一次尝试变成可玩的原型",createdAt:0}];
export default function VoteClient(){
 const {market,error,refresh}=useMarket(); const [selected,setSelected]=useState(""); const [busy,setBusy]=useState(false); const [submitted,setSubmitted]=useState(false); const [message,setMessage]=useState(""); const [demo,setDemo]=useState(false); const [demoVotes,setDemoVotes]=useState<Record<string,number>>({}); const [burst,setBurst]=useState<VoteBurstData|null>(null);
 useEffect(()=>{const id=new URLSearchParams(window.location.search).get("team");if(id)setSelected(id);},[]);
 const teams=demo?(market?.teams.length?market.teams:demoTeams):(market?.teams||[]);
 const liveVotes=(market?.events||[]).filter(e=>e.kind==="vote"&&e.status==="open"&&!e.demo);
 const ranked=teams.map((t,i)=>({...t,votes:demo?(demoVotes[t.id]||0):(market?.voteCounts?.[t.id]||0),index:i})).sort((a,b)=>b.votes-a.votes);
 const total=ranked.reduce((n,t)=>n+t.votes,0); const selectedTeam=teams.find(t=>t.id===selected);
 async function submit(){if(!selected||busy||demo||submitted)return;setBusy(true);setMessage("");try{await sendAction({kind:"vote",teamId:selected});setSubmitted(true);setMessage(`已把支持送给 ${selectedTeam?.name}。谢谢你的这一票！`);setBurst({id:`live-${Date.now()}`,team:selectedTeam?.name||"现场队伍",demo:false});await refresh();}catch(e){setMessage(e instanceof Error?e.message:"暂时未送达，请稍后重试");}finally{setBusy(false);}}
 function simulate(){if(!selected)return;setDemoVotes(v=>({...v,[selected]:(v[selected]||0)+1}));setBurst({id:`demo-${Date.now()}`,team:selectedTeam?.name||"演示队伍",demo:true});setMessage("演示支持已点亮。未提交真实选票。");}
 return <main className="event-page"><EventHeader active="作品 / 投票"/><SampleNotice teams={market?.teams||[]}/><div className="inner-wrap"><div className="event-eyebrow"><i/> IDEAS DESERVE AN AUDIENCE</div><div className="ballot-title"><div><h1>把你的<span>支持</span><br/>交给一个好点子。</h1><p>看见作品背后的人。每台设备一票，支持会同步到现场大屏。</p></div><div className="vote-total"><Vote size={28}/><b>{total}</b><span>{demo?"本机演示票数":"真实选票已送达"}</span></div></div>
 {demo&&<div className="demo-banner" role="status"><strong>本机演示 · 与真实票数隔离</strong><span>体验投票光效和票数变化，不写入服务器。</span><button onClick={()=>{setDemo(false);setSelected("");setMessage("");setBurst(null);}}>退出演示</button></div>}
 {!demo&&error&&<p className="event-error" role="status">{error}</p>}
 <div className="ballot-layout"><section><div className="event-section-title"><div><small>01 / PICK YOUR FAVORITE</small><h2>作品背后，都是今晚的创造者。</h2></div></div><div className="ballot-grid">{teams.map((t,i)=><button className={`ballot-option ${selected===t.id?"selected":""}`} aria-pressed={selected===t.id} onClick={()=>{setSelected(t.id);setMessage("");}} key={t.id}><div className={`project-art art-${i%4}`}><span>{t.code.slice(0,3)}</span><i/><b>BUILT TONIGHT</b></div><div className="project-copy"><small>TEAM {String(i+1).padStart(2,"0")} {selected===t.id&&<Check size={18}/>}</small><h3>{t.name}</h3>{sampleIds.has(t.id)&&<small>示例作品 / 非真实参赛队</small>}<p>{t.idea}</p></div></button>)}</div>{!teams.length&&<div className="event-empty">等待队伍入场。可先用下面的本机演示看看投票效果。</div>}
 <div className="ballot-submit-wrap"><span>{selectedTeam?`已选择：${selectedTeam.name}`:"先选一个打动你的点子"}</span><button className="event-button" disabled={!selected||busy||(!demo&&submitted)} onClick={demo?simulate:submit}>{busy?"送达中…":demo?"送一票演示支持":submitted?"本设备已投票 ✓":"确认投出这一票"}<ArrowUpRight size={20}/></button><small>{demo?"仅本机体验，可重复点击":"正式投票后无法改票，请确认选择。票数不代表评审成绩。"}</small>{message&&<p className="ballot-message" role="status">{message}</p>}</div></section>
 <aside className="support-board"><RankingBoard teams={teams} counts={demo?demoVotes:(market?.voteCounts||{})} demo={demo}/></aside></div>
 <section className="demo-entry"><div><small>TRY BEFORE THE FIRST VOTE</small><h3>想看看投票后的样子？</h3><p>本机演示可以重复体验，不影响正式投票。</p></div><button className="event-link" onClick={()=>{setDemo(true);setSelected("");setMessage("");setDemoVotes({});}}>开始本机演示 <ArrowUpRight size={18}/></button></section></div><VoteBurst burst={burst}/></main>;
}
